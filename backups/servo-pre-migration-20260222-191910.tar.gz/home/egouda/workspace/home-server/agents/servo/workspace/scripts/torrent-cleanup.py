#!/usr/bin/env python3
"""
Torrent Cleanup Script
Removes completed torrents from qBittorrent once:
  - They've been imported by Sonarr/Radarr (not in queue), AND
  - Either: ratio >= 1.0 OR age >= 7 days since completion

Only touches torrents in managed categories (tv-sonarr, radarr).
Uncategorized/manual torrents are left alone.
"""

import json
import time
import logging
import sys
import urllib.request
import urllib.parse
import http.cookiejar

# === CONFIG ===
QBIT_URL = "http://192.168.0.124:15080"
QBIT_USER = "admin"
QBIT_PASS = "adminadmin"

SONARR_URL = "http://172.18.0.1:8989"
SONARR_KEY = "ad199dd8360c491aa16275349254c169"

RADARR_URL = "http://172.18.0.1:7878"
RADARR_KEY = "effde01319db4e8788ecee395fb4b73c"

# Cleanup thresholds
MAX_RATIO = 1.0
MAX_AGE_DAYS = 7

# Category -> arr app mapping
MANAGED_CATEGORIES = {
    "tv-sonarr": {"url": SONARR_URL, "key": SONARR_KEY, "name": "Sonarr"},
    "radarr":    {"url": RADARR_URL, "key": RADARR_KEY, "name": "Radarr"},
}

DRY_RUN = "--dry-run" in sys.argv

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("torrent-cleanup")


class QBitClient:
    def __init__(self, url, user, password):
        self.url = url.rstrip("/")
        self.cj = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.cj))
        self._login(user, password)

    def _login(self, user, password):
        data = urllib.parse.urlencode({"username": user, "password": password}).encode()
        req = urllib.request.Request(f"{self.url}/api/v2/auth/login", data=data)
        resp = self.opener.open(req)
        body = resp.read().decode()
        if body.strip() != "Ok.":
            raise RuntimeError(f"qBit login failed: {body}")

    def get_torrents(self):
        req = urllib.request.Request(f"{self.url}/api/v2/torrents/info")
        resp = self.opener.open(req)
        return json.loads(resp.read())

    def delete_torrent(self, torrent_hash, delete_files=True):
        data = urllib.parse.urlencode({
            "hashes": torrent_hash,
            "deleteFiles": str(delete_files).lower(),
        }).encode()
        req = urllib.request.Request(f"{self.url}/api/v2/torrents/delete", data=data)
        self.opener.open(req)


def arr_get_queue_hashes(url, api_key):
    """Get all download hashes currently in an *arr queue (not yet imported)."""
    hashes = set()
    page = 1
    page_size = 100
    while True:
        api_url = f"{url}/api/v3/queue?page={page}&pageSize={page_size}"
        req = urllib.request.Request(api_url, headers={"X-Api-Key": api_key})
        resp = urllib.request.urlopen(req)
        data = json.loads(resp.read())
        for record in data.get("records", []):
            dl_id = record.get("downloadId", "")
            if dl_id:
                hashes.add(dl_id.lower())
        if page * page_size >= data.get("totalRecords", 0):
            break
        page += 1
    return hashes


def main():
    if DRY_RUN:
        log.info("=== DRY RUN MODE — no torrents will be removed ===")

    now = time.time()

    # Connect to qBittorrent
    log.info("Connecting to qBittorrent...")
    qbit = QBitClient(QBIT_URL, QBIT_USER, QBIT_PASS)
    torrents = qbit.get_torrents()
    log.info(f"Found {len(torrents)} total torrents")

    # Get queue hashes from Sonarr and Radarr (these are NOT yet imported)
    queue_hashes = {}
    for cat, arr in MANAGED_CATEGORIES.items():
        try:
            hashes = arr_get_queue_hashes(arr["url"], arr["key"])
            queue_hashes[cat] = hashes
            log.info(f"{arr['name']} queue: {len(hashes)} pending downloads")
        except Exception as e:
            log.error(f"Failed to get {arr['name']} queue: {e}")
            queue_hashes[cat] = None  # None = skip this category (safe fallback)

    removed = 0
    skipped = 0

    for t in torrents:
        name = t["name"]
        cat = t.get("category", "")
        ratio = t["ratio"]
        t_hash = t["hash"]
        completion_on = t.get("completion_on", 0)

        # Only touch managed categories
        if cat not in MANAGED_CATEGORIES:
            continue

        # Skip if still downloading
        if completion_on <= 0:
            log.debug(f"SKIP (incomplete): {name}")
            skipped += 1
            continue

        age_days = (now - completion_on) / 86400

        # Check if either threshold is met
        ratio_met = ratio >= MAX_RATIO
        age_met = age_days >= MAX_AGE_DAYS

        if not (ratio_met or age_met):
            log.debug(f"SKIP (ratio={ratio:.3f}, age={age_days:.1f}d): {name}")
            skipped += 1
            continue

        # Safety: if we couldn't reach the *arr app, skip
        if queue_hashes[cat] is None:
            log.warning(f"SKIP (can't verify import, {MANAGED_CATEGORIES[cat]['name']} unreachable): {name}")
            skipped += 1
            continue

        # Check if torrent is still in the *arr queue (not yet imported)
        if t_hash.lower() in queue_hashes[cat]:
            log.info(f"SKIP (still in {MANAGED_CATEGORIES[cat]['name']} queue, not imported yet): {name}")
            skipped += 1
            continue

        # All checks passed — remove it
        reason = []
        if ratio_met:
            reason.append(f"ratio={ratio:.3f}")
        if age_met:
            reason.append(f"age={age_days:.1f}d")

        if DRY_RUN:
            log.info(f"WOULD REMOVE [{', '.join(reason)}]: {name}")
        else:
            try:
                qbit.delete_torrent(t_hash, delete_files=True)
                log.info(f"REMOVED [{', '.join(reason)}]: {name}")
                removed += 1
            except Exception as e:
                log.error(f"FAILED to remove {name}: {e}")

    log.info(f"Done. Removed: {removed}, Skipped: {skipped}")


if __name__ == "__main__":
    main()
