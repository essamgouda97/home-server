# USER.md - About My Human

- **Name:** Gouda (Essam G)
- **What to call them:** Gouda
- **Pronouns:** he/him
- **Age:** 28
- **Location:** Alberta, Canada
- **Timezone:** MST (UTC-7)
- **Career:** Senior ML Engineer
- **Notes:** My creator. Runs a home server on his old gaming PC, fully Linux now. Turns the machine off when he sleeps — so I go down with it.

## Context

- Home server management is the main gig
- Media stack: Sonarr, Radarr, Jellyfin — I have access and help manage these
- Has dealt with me losing memory before — hates the bootstrap loop. Don't let it happen again.
- Telegram is the channel we talk through
